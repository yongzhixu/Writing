//
//  ViewController.m
//  demo
//
//  Created by gujicheng on 2018/5/17.
//  Copyright © 2018年 gujicheng. All rights reserved.
//

#import<AVFoundation/AVFoundation.h>
#import <sinvoice/sinvoice.h>
#import "ViewController.h"
#import "downpicker/UIDownPicker.h"

@interface ViewController ()<SinVoiceDelegate>
{
    SinVoice* _sinVoice;
    UIDownPicker *_effectList;
    UIDownPicker *_customList;
}
@property (weak, nonatomic) IBOutlet UITextView *tvResult;
@property (weak, nonatomic) IBOutlet UILabel *lableCopyright;
@property (weak, nonatomic) IBOutlet UIButton *btnListen;
@property (weak, nonatomic) IBOutlet UILabel *labelStatus;
@property (weak, nonatomic) IBOutlet UITextView *tvSendText;
@property (weak, nonatomic) IBOutlet UIButton *btnSend;
@property (weak, nonatomic) IBOutlet UILabel *labelInfo;
@property (weak, nonatomic) IBOutlet UILabel *effect;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    _sinVoice = [[SinVoice alloc] initWithDelegate:self];

    [self.labelInfo setLineBreakMode:NSLineBreakByWordWrapping];
    self.labelInfo.numberOfLines = 0;
    
    self.btnSend.layer.borderWidth = 1.0f;
    self.btnSend.layer.cornerRadius = 4.0f;
    self.btnSend.layer.masksToBounds = YES;
    
    CGColorRef boderColor = [[UIColor colorWithRed:215.0 / 255.0 green:215.0 / 255.0 blue:215.0 / 255.0 alpha:1] CGColor];
    self.tvSendText.layer.borderColor = boderColor;
    self.tvSendText.layer.borderWidth = 0.6f;
    self.tvSendText.layer.cornerRadius = 6.0f;
    
    self.tvResult.layer.borderColor = boderColor;
    self.tvResult.layer.borderWidth = 0.6f;
    self.tvResult.layer.cornerRadius = 6.0f;

    self.btnListen.layer.borderWidth = 1.0f;
    self.btnListen.layer.cornerRadius = 4.0f;
    self.btnListen.layer.masksToBounds = YES;

    [self.tvResult setEditable:NO];

    [self addEffectList];
    [self addCustomList];    
}

- (IBAction)send:(id)sender {
    if ([_sinVoice sending]) {
        [_sinVoice stopSend];
    } else {
        [_sinVoice sendText:[_tvSendText text]];
    }
}

- (IBAction)listen:(id)sender {
    if ([_sinVoice listening]) {
        [_sinVoice stopListen];
    } else {
        [_sinVoice startListen];
    }
}

-(void)onSinVoiceSendStart {
    [_btnSend setTitle:NSLocalizedString(@"stop_send", nil) forState:UIControlStateNormal];
}

-(void)onSinVoiceSendFinish {
    [_btnSend setTitle:NSLocalizedString(@"send_data", nil) forState:UIControlStateNormal];
}

-(void)onSinVoiceStartListen {
    [_btnListen setTitle:NSLocalizedString(@"stop_listen", nil) forState:UIControlStateNormal];

    [_labelStatus setText:[NSString stringWithFormat:@"%@%@",NSLocalizedString(@"state", @""), NSLocalizedString(@"listening_sonic", nil)]];
}

-(void)onSinVoiceStopListen {
    [_btnListen setTitle:NSLocalizedString(@"start_listen", nil) forState:UIControlStateNormal];
    
    [_labelStatus setText:[NSString stringWithFormat:@"%@%@",NSLocalizedString(@"state", nil), NSLocalizedString(@"stop_listen_sonic", nil)]];
}

-(void)onSinVoiceReceiveStart {
    [_labelStatus setText:[NSString stringWithFormat:@"%@%@",NSLocalizedString(@"state", nil), NSLocalizedString(@"receiving_data", nil)]];
}

-(void)onSinVoiceReceiveSucessWithResult:(NSString*) result {
    [_labelStatus setText:[NSString stringWithFormat:@"%@%@%@",NSLocalizedString(@"state", nil), NSLocalizedString(@"listening_sonic", nil), NSLocalizedString(@"received_successful", nil)]];
    
    [_tvResult setText:result];
}

-(void)onSinVoiceReceiveFailed {
    [_labelStatus setText:[NSString stringWithFormat:@"%@%@%@",NSLocalizedString(@"state", nil), NSLocalizedString(@"listening_sonic", nil), NSLocalizedString(@"received_failed", nil)]];
}

-(void)addEffectList {
    NSMutableArray* bandArray = [[NSMutableArray alloc] init];
    
    [bandArray addObject:NSLocalizedString(@"sonic", nil)];
    [bandArray addObject:NSLocalizedString(@"supersonic", nil)];
    [bandArray addObject:NSLocalizedString(@"custom", nil)];
    
    _effectList = [[UIDownPicker alloc] initWithData:bandArray];
    _effectList.text = bandArray[0];
    _effectList.borderStyle = UITextBorderStyleRoundedRect;
    [self.view addSubview:_effectList];
    
    _effectList.translatesAutoresizingMaskIntoConstraints = NO;
    
    NSDictionary* namedMap = @{@"effect":self.effect, @"effectList": _effectList, @"info":self.labelInfo};
    
    NSArray* hContraints = [NSLayoutConstraint constraintsWithVisualFormat:@"H:[effect]-5-[effectList(==140)]" options:0 metrics:nil views:namedMap];
    
    NSArray* vContraints = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[info]-5-[effectList(==30)]" options:0 metrics:nil views:namedMap];
    
    [self.view addConstraints:hContraints];
    [self.view addConstraints:vContraints];
    
    [_effectList.DownPicker addTarget:self
                    action:@selector(dp_Selected:)
          forControlEvents:UIControlEventValueChanged];
}

-(void)addCustomList {
    NSMutableArray* bandArray = [[NSMutableArray alloc] init];
    [bandArray addObject:NSLocalizedString(@"doorbell", nil)];
    [bandArray addObject:NSLocalizedString(@"bark", nil)];
    [bandArray addObject:NSLocalizedString(@"xiuxiu", nil)];
    
    _customList = [[UIDownPicker alloc] initWithData:bandArray];
    _customList.text = bandArray[0];
    _customList.borderStyle = UITextBorderStyleRoundedRect;
    [self.view addSubview:_customList];
    
    _customList.translatesAutoresizingMaskIntoConstraints = NO;
    
    NSDictionary* namedMap = @{@"effectList":_effectList, @"customList": _customList, @"info":self.labelInfo};
    
    NSArray* hContraints = [NSLayoutConstraint constraintsWithVisualFormat:@"H:[effectList]-5-[customList(==120)]" options:0 metrics:nil views:namedMap];
    
    NSArray* vContraints = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[info]-5-[customList(==30)]" options:0 metrics:nil views:namedMap];
    
    [self.view addConstraints:hContraints];
    [self.view addConstraints:vContraints];
    
    [_customList.DownPicker addTarget:self
                    action:@selector(dp_Selected:)
          forControlEvents:UIControlEventValueChanged];
    
    [_customList setHidden:YES];
}

- (void)viewWillAppear:(BOOL)animated {
    [_sinVoice startListen];
}

- (void)viewWillDisappear:(BOOL)animated {
    [_sinVoice stop];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dp_Selected:(id)dp {
    NSString* text = [dp text];
    if (dp == _effectList.DownPicker) {
        NSLog(@"selected effectList: %@", [dp text]);
        SVEffect effect = SV_EFFECT_SONIC;
        if ([text isEqualToString:NSLocalizedString(@"custom", nil)]) {
            effect = SV_EFFECT_CUSTOM;
            [_customList setHidden:NO];
            [_customList setText:NSLocalizedString(@"doorbell", nil)];
        } else {
            [_customList setHidden:YES];
            if ([text isEqualToString:NSLocalizedString(@"sonic", nil)]) {
                effect = SV_EFFECT_SONIC;
            } else if ([text isEqualToString:NSLocalizedString(@"supersonic", nil)]) {
                effect = SV_EFFECT_SUPER_SONIC;
            }
        }

        [_sinVoice setEffect:effect];
    } else {
        NSString* text = [dp text];
        NSLog(@"selected effectList: %@", [dp text]);
        SVCustomEffectType type = SV_CUSTOM_EFFECT_NONE;
        if ([text isEqualToString:NSLocalizedString(@"doorbell", nil)]) {
            type = SV_CUSTOM_EFFECT_DOORBELL;
        } else if ([text isEqualToString:NSLocalizedString(@"bark", nil)]) {
            type = SV_CUSTOM_EFFECT_BARK;
        } else if ([text isEqualToString:NSLocalizedString(@"xiuxiu", nil)]) {
            type = SV_CUSTOM_EFFECT_XIUXIU;
        }
        [_sinVoice setCustomEffectType:type];
    }
}
@end

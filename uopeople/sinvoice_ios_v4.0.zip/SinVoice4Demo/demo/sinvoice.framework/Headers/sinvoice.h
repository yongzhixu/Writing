//
//  SinVoice.h
//  sinvoice
//
//  Created by gujicheng on 2018/5/18.
//  Copyright © 2018年 gujicheng. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef NS_ENUM(NSInteger, SVEffect) {
    SV_EFFECT_SONIC = 1,
    SV_EFFECT_SUPER_SONIC,
    SV_EFFECT_CUSTOM,
};

typedef NS_ENUM(NSInteger, SVCustomEffectType) {
    SV_CUSTOM_EFFECT_NONE = -1,
    SV_CUSTOM_EFFECT_DOORBELL,
    SV_CUSTOM_EFFECT_BARK,
    SV_CUSTOM_EFFECT_XIUXIU,
};

@protocol SinVoiceDelegate
-(void)onSinVoiceSendStart;
-(void)onSinVoiceSendFinish;
-(void)onSinVoiceStartListen;
-(void)onSinVoiceStopListen;
-(void)onSinVoiceReceiveStart;
-(void)onSinVoiceReceiveSucessWithResult:(NSString*) result;
-(void)onSinVoiceReceiveFailed;
@end

@interface SinVoice : NSObject
@property(nonatomic, weak)id<SinVoiceDelegate> delegate;

-(instancetype)initWithDelegate:(id<SinVoiceDelegate>)delegate;
-(BOOL)sending;
-(BOOL)listening;

-(void)setCustomEffectType:(SVCustomEffectType) type;
-(void)setEffect:(SVEffect)effect;

-(void)sendText:(NSString*)text;
-(void)stopSend;

-(void)startListen;
-(void)stopListen;

-(void)stop;
@end
